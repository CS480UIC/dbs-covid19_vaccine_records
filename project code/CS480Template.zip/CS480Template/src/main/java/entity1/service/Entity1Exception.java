package entity1.service;

public class Entity1Exception extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Entity1Exception() {
		super();
	}

	public Entity1Exception(String message) {
		super(message);
	}

}
